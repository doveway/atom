<?php
include_once 'secure.php';
?>
<!doctype html>
<html lang="zxx">
<head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <!-- Links of CSS files -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/css/animate.min.css">
        <link rel="stylesheet" href="assets/css/fontawesome.min.css">
        <link rel="stylesheet" href="assets/css/flaticon.css">
        <link rel="stylesheet" href="assets/css/magnific-popup.min.css">
        <link rel="stylesheet" href="assets/css/nice-select.css">
        <link rel="stylesheet" href="assets/css/slick.min.css">
        <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
        <link rel="stylesheet" href="assets/css/meanmenu.css">
		<link rel="stylesheet" href="assets/css/odometer.min.css">
        <link rel="stylesheet" href="assets/css/style.css">
        <link rel="stylesheet" href="assets/css/responsive.css">

        <title>ATOM LOANS::Agents</title>

        <link rel="icon" type="image/png" href="assets/img/favicon.png">
    </head>

        <!-- Preloader -->
        <div class="preloader">
            <div class="loader">
                <div class="shadow"></div>
                <div class="box"></div>
            </div>
        </div>
        <!-- End Preloader -->

        <!-- Start Navbar Area -->
        <?php include_once 'navbar.php'; ?>
        <!-- End Navbar Area -->
        
        <!-- Start Page Title Area -->
        <div class="page-title-area item-bg1 jarallax" data-jarallax='{"speed": 0.3}'>
            <div class="container">
                <div class="page-title-content">
                    <h2>Become an Agent</h2>
                    <p>levels of agents</p>
                </div>
            </div>
        </div>
        <!-- End Page Title Area -->

        <!-- Start Pricing Area -->
        <section class="pricing-area ptb-70">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-6 col-sm-6">
                        <div class="single-pricing-box">
                            <div class="pricing-header">
                                <h3>Silver Agents</h3>
                                <p>Become a partner</p>
                            </div>

                            <div class="price" style="font-size:30px;">
                                &#x20a6;50,000.00<span></span>
                            </div>

                            <div class="buy-btn">
                                <a href="#" class="btn btn-primary">Choose this plan</a>
                            </div>

                            <ul class="pricing-features">
                                <li><i class="fas fa-check"></i> 3.5% commission on each direct loan</li>
                                <li><i class="fas fa-check"></i> 1.5% commission on each indirect loan </li>
                                <li><i class="fas fa-check"></i> You can surety loans up to &#x20a6;25,000.00</li>
                                <li><i class="fas fa-check"></i> Loan up to &#x20a6;2Million per month</li>
                                <li><i class="fas fa-check"></i> Training </li>
                            </ul>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6 col-sm-6">
                        <div class="single-pricing-box">
                            <div class="pricing-header">
                                <h3>Gold Agents</h3>
                                <p>Become a partner</p>
                            </div>

                            <div class="price" style="font-size:30px;">
                                 &#x20a6;100,000.00 <span></span>
                            </div>

                            <div class="buy-btn">
                                <a href="#" class="btn btn-primary">Choose this plan</a>
                            </div>

                            <ul class="pricing-features">
                                <li><i class="fas fa-check"></i> 5% commission on each direct loan</li>
                                <li><i class="fas fa-check"></i> 2% commission on each indirect loan </li>
                                <li><i class="fas fa-check"></i> You can surety loans up to &#x20a6;50,000.00</li>
                                <li><i class="fas fa-check"></i> Loan up to &#x20a6;5Million per month</li>
                                <li><i class="fas fa-check"></i> Training </li>
                                <li><i class="fas fa-check"></i> ATOM branded items </li>
                                <li><i class="fas fa-check"></i> Free pass to ATOM events </li>
                            </ul>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6 col-sm-6 offset-lg-0 offset-md-3 offset-sm-3">
                        <div class="single-pricing-box">
                            <div class="pricing-header">
                                <h3>Platinum Agents</h3>
                                <p>Become a partner</p>
                            </div>

                            <div class="price" style="font-size:30px;">
                                 &#x20a6;200,000.00 <span></span>
                            </div>

                            <div class="buy-btn">
                                <a href="#" class="btn btn-primary">Choose this plan</a>
                            </div>

                            <ul class="pricing-features">
                                <li><i class="fas fa-check"></i> 5% commission on each direct loan</li>
                                <li><i class="fas fa-check"></i> 2% commission on each indirect loan </li>
                                <li><i class="fas fa-check"></i> You can surety loans up to &#x20a6;100,000.00</li>
                                <li><i class="fas fa-check"></i> Loan up to &#x20a6;10Million per month</li>
                                <li><i class="fas fa-check"></i> Training </li>
                                <li><i class="fas fa-check"></i> ATOM branded items </li>
                                <li><i class="fas fa-check"></i> Free pass to ATOM events </li>
                                <li><i class="fas fa-check"></i> Collateral auction priority </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Pricing Area -->

        <!-- Start Account Create Area -->
        <section class="account-create-area">
            <div class="container">
                <div class="account-create-content">
                    <h2>Create an account Now</h2>
                    <p>It takes less than 2 minutes to open an account</p>
                    <a href="signup.php" class="btn btn-primary">Get Your atom Account</a>
                </div>
            </div>
        </section>
        <!-- End Account Create Area -->
        
        <!-- Start Footer Area -->
		<footer class="footer-area">
			<div class="container">
				<div class="row">
					<div class="col-lg-3 col-sm-6 col-md-6">
						<div class="single-footer-widget">
							<div class="logo">
								<a href="index-2.html"><img src="assets/img/black-logo.png" alt="logo"></a>
                                <p>Quis ipsum suspendisse ultrices gravida commodo. Risus commodo veliliee vel viverra maecenas accumsan lacus vel facilisis.</p>
							</div>
                            
							<ul class="social-links">
								<li><a href="#" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
								<li><a href="#" target="_blank"><i class="fab fa-twitter"></i></a></li>
								<li><a href="#" target="_blank"><i class="fab fa-instagram"></i></a></li>
								<li><a href="#" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
							</ul>
						</div>
					</div>

					<div class="col-lg-3 col-sm-6 col-md-6">
						<div class="single-footer-widget pl-5">
                            <h3>Company</h3>
                            
							<ul class="list">
								<li><a href="#">About Us</a></li>
								<li><a href="#">Services</a></li>
								<li><a href="#">Features</a></li>
								<li><a href="#">Our Pricing</a></li>
								<li><a href="#">Latest News</a></li>
							</ul>
						</div>
					</div>

					<div class="col-lg-3 col-sm-6 col-md-6">
						<div class="single-footer-widget">
                            <h3>Support</h3>
                            
							<ul class="list">
								<li><a href="#">FAQ's</a></li>
								<li><a href="#">Privacy Policy</a></li>
								<li><a href="#">Terms & Condition</a></li>
								<li><a href="#">Community</a></li>
								<li><a href="#">Contact Us</a></li>
							</ul>
						</div>
					</div>

					<div class="col-lg-3 col-sm-6 col-md-6">
						<div class="single-footer-widget">
							<h3>Address</h3>
							
							<ul class="footer-contact-info">
								<li><span>Location:</span> 27 Division St, New York, NY 10002, USA</li>
								<li><span>Email:</span> <a href="mailto:hello@luvion.com">hello@luvion.com</a></li>
								<li><span>Phone:</span> <a href="tel:+321984754">+ (321) 984 754</a></li>
								<li><span>Fax:</span> <a href="tel:+12129876543">+1-212-9876543</a></li>
                            </ul>
						</div>
					</div>
				</div>

                <div class="copyright-area">
                    <p>Copyright @2020 <a href="#">Luvion</a>. All rights reserved</p>
                </div>
            </div>
            
            <div class="map-image"><img src="assets/img/map.png" alt="map"></div>
		</footer>
        <!-- End Footer Area -->
        
        <div class="go-top"><i class="fas fa-arrow-up"></i></div>

        <!-- Links of JS files -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/popper.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/jquery.meanmenu.js"></script>
        <script src="assets/js/jquery.nice-select.min.js"></script>
        <script src="assets/js/slick.min.js"></script>
        <script src="assets/js/jquery.magnific-popup.min.js"></script>
		<script src="assets/js/jquery.appear.min.js"></script>
        <script src="assets/js/odometer.min.js"></script>
        <script src="assets/js/owl.carousel.min.js"></script>
        <script src="assets/js/parallax.min.js"></script>
        <script src="assets/js/wow.min.js"></script>
        <script src="assets/js/form-validator.min.js"></script>
        <script src="assets/js/contact-form-script.js"></script>
        <script src="assets/js/main.js"></script>
    </body>

<!-- Mirrored from templates.envytheme.com/luvion/default/pricing.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 03 Aug 2020 23:33:00 GMT -->
</html>