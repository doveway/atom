<?php
include_once 'secure.php';
?>
<!doctype html>
<html lang="zxx">
<head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <!-- Links of CSS files -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/css/animate.min.css">
        <link rel="stylesheet" href="assets/css/fontawesome.min.css">
        <link rel="stylesheet" href="assets/css/flaticon.css">
        <link rel="stylesheet" href="assets/css/magnific-popup.min.css">
        <link rel="stylesheet" href="assets/css/nice-select.css">
        <link rel="stylesheet" href="assets/css/slick.min.css">
        <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
        <link rel="stylesheet" href="assets/css/meanmenu.css">
		<link rel="stylesheet" href="assets/css/odometer.min.css">
        <link rel="stylesheet" href="assets/css/style.css">
        <link rel="stylesheet" href="assets/css/responsive.css">

        <title>ATOM LOANS::FAQ</title>

        <link rel="icon" type="image/png" href="assets/img/favicon.png">
    </head>

        <!-- Preloader -->
        <div class="preloader">
            <div class="loader">
                <div class="shadow"></div>
                <div class="box"></div>
            </div>
        </div>
        <!-- End Preloader -->

        <!-- Start Navbar Area -->
        <?php include_once 'navbar.php'; ?>
        <!-- End Navbar Area -->
        
        <!-- Start Page Title Area -->
        <div class="page-title-area item-bg1 jarallax" data-jarallax='{"speed": 0.3}'>
            <div class="container">
                <div class="page-title-content">
                    <h2>FAQ</h2>
                    <p>Frequently Asked Questions</p>
                </div>
            </div>
        </div>
        <!-- End Page Title Area -->

        <!-- Start FAQ Area -->
        <section class="faq-area ptb-70">
            <div class="container">
                <div class="row">
                    <div class="col-lg-5 col-md-12">
                        <div class="faq-content">
                            <h2>Frequently Asked Questions</h2>
                            <div class="bar"></div>
                            <p></p>

                            <div class="faq-image">
                                <img src="assets/img/faq.png" alt="image">
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-7 col-md-12">
                        <div class="faq-accordion">
                            <ul class="accordion">
                                
                                <li class="accordion-item">
                                    <a class="accordion-title active" href="javascript:void(0)">
                                        <i class="fas fa-plus"></i>
                                        How much can i borrow?
                                    </a>

                                    <p class="accordion-content show">Between &#x20a6;5,000.00 and &#x20a6;100,000.00.</p>
                                </li>
                                
                                <li class="accordion-item">
                                    <a class="accordion-title" href="javascript:void(0)">
                                        <i class="fas fa-plus"></i>
                                        I stole the device, can i use it as collateral?
                                    </a>

                                    <p class="accordion-content">No! We will hand you over to the law enforcement agencies if discovered. Remember we have your information.</p>
                                </li>
                                
                                <li class="accordion-item">
                                    <a class="accordion-title" href="javascript:void(0)">
                                        <i class="fas fa-plus"></i>
                                        Do i need a collateral?
                                    </a>

                                    <p class="accordion-content">Yes. Collaterals accepted include smart phones, tablets, and generally light weight gadgets.</p>
                                </li>
                                
                                <li class="accordion-item">
                                    <a class="accordion-title" href="javascript:void(0)">
                                        <i class="fas fa-plus"></i>
                                        What happens if i default?
                                    </a>

                                    <p class="accordion-content">Your collateral will be sold to attempt recovering loan.</p>
                                </li>

                                <li class="accordion-item">
                                    <a class="accordion-title" href="javascript:void(0)">
                                        <i class="fas fa-plus"></i>
                                        The gadget is not mine, can i use it?
                                    </a>

                                    <p class="accordion-content">No. You can only use your gadget, so the owner of the device does not reach out to us. In such a case, you may face legal actions from us.</p>
                                </li>
                                
                                
                                
                                <li class="accordion-item">
                                    <a class="accordion-title" href="javascript:void(0)">
                                        <i class="fas fa-plus"></i>
                                        How do I become an agent?
                                    </a>

                                    <p class="accordion-content">Click <a href="agent.php">here</a> to choose a package.</p>
                                </li>

                                
                            </ul>
                        </div>
                    </div>
                </div>

            </div>
        </section>
        <!-- End FAQ Area -->

        <!-- Start Account Create Area -->
        <section class="account-create-area">
            <div class="container">
                <div class="account-create-content">
                    <h2>Create an account Now</h2>
                    <p>It takes less than 2 minutes to open an account</p>
                    <a href="signup.php" class="btn btn-primary">Get Your atom Account</a>
                </div>
            </div>
        </section>
        <!-- End Account Create Area -->
        
        <!-- Start Footer Area -->
		<?php include_once 'footer.php'; ?>
        <!-- End Footer Area -->
        
        <div class="go-top"><i class="fas fa-arrow-up"></i></div>

        <!-- Links of JS files -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/popper.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/jquery.meanmenu.js"></script>
        <script src="assets/js/jquery.nice-select.min.js"></script>
        <script src="assets/js/slick.min.js"></script>
        <script src="assets/js/jquery.magnific-popup.min.js"></script>
		<script src="assets/js/jquery.appear.min.js"></script>
        <script src="assets/js/odometer.min.js"></script>
        <script src="assets/js/owl.carousel.min.js"></script>
        <script src="assets/js/parallax.min.js"></script>
        <script src="assets/js/wow.min.js"></script>
        <script src="assets/js/form-validator.min.js"></script>
        <script src="assets/js/contact-form-script.js"></script>
        <script src="assets/js/main.js"></script>
    </body>

</html>