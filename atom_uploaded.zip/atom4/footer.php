<footer class="footer-area">
			<div class="container">
				<div class="row">
					<div class="col-lg-3 col-sm-6 col-md-6">
						<div class="single-footer-widget">
							<div class="logo">
								<a href="index-3.html"><img src="assets/img/black-logo.png" alt="logo"></a>
                                <p>At atom loans we take off those financial stress from you by providing small loans and investment for those seeking financial freedom.</p>
							</div>
                            
							<ul class="social-links">
								<li><a href="https://web.facebook.com/atomloans" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
								<li><a href="https://twitter.com/atomloans" target="_blank"><i class="fab fa-twitter"></i></a></li>
								<li><a href="https://www.instagram.com/atomloans" target="_blank"><i class="fab fa-instagram"></i></a></li>
								<li><a href="#" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
							</ul>
						</div>
					</div>

					<div class="col-lg-3 col-sm-6 col-md-6">
						<div class="single-footer-widget pl-5">
                            <h3>Company</h3>
                            
							<ul class="list">
								<li><a href="#">About Us</a></li>
								<li><a href="signup.php">Get a Loan</a></li>
								<li><a href="invest.php">Invest</a></li>
								<li><a href="agent.php">Become an Agent</a></li>
							</ul>
						</div>
					</div>

					<div class="col-lg-3 col-sm-6 col-md-6">
						<div class="single-footer-widget">
                            <h3>Support</h3>
                            
							<ul class="list">
								<li><a href="faq.php">FAQ's</a></li>
								<li><a href="#">Privacy Policy</a></li>
								<li><a href="tandc.php">Terms &amp; Condition</a></li>
								<li><a href="contact.php">Contact Us</a></li>
							</ul>
						</div>
					</div>

					<div class="col-lg-3 col-sm-6 col-md-6">
						<div class="single-footer-widget">
							<h3>Address</h3>
							
							<ul class="footer-contact-info">
								<li><span>Location:</span> Lekki, Lagos, Nigeria</li>
								<li><span>Email:</span> <a href="mailto:hello@atomloans.ng">hello@atomloans.ng</a></li>
								<li><span>Phone:</span> <a href="tel:+321984754">+ (234) 806 517 8535</a></li>
								<!-- <li><span>Phone:</span> <a href="tel:+321984754">+ (234) 8064 754</a></li> -->
                            </ul>
						</div>
					</div>
				</div>

                <div class="copyright-area">
                    <p>Copyright @2021 <a href="#">ATOM LOANS</a>. All rights reserved</p>
                </div>
            </div>
            
		</footer>