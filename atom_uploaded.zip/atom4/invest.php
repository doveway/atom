<!doctype html>
<html lang="zxx">
    
<head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <!-- Links of CSS files -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/css/animate.min.css">
        <link rel="stylesheet" href="assets/css/fontawesome.min.css">
        <link rel="stylesheet" href="assets/css/flaticon.css">
        <link rel="stylesheet" href="assets/css/magnific-popup.min.css">
        <link rel="stylesheet" href="assets/css/nice-select.css">
        <link rel="stylesheet" href="assets/css/slick.min.css">
        <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
        <link rel="stylesheet" href="assets/css/meanmenu.css">
		<link rel="stylesheet" href="assets/css/odometer.min.css">
        <link rel="stylesheet" href="assets/css/style.css">
        <link rel="stylesheet" href="assets/css/responsive.css">

        <title>atom loans::Invest</title>

        <link rel="icon" type="image/png" href="assets/img/favicon.png">
    </head>

    <body>

        <!-- Preloader -->
        <div class="preloader">
            <div class="loader">
                <div class="shadow"></div>
                <div class="box"></div>
            </div>
        </div>
        <!-- End Preloader -->

        <!-- Start Navbar Area -->
        <?php include_once 'navbar.php'; ?>
        <!-- End Navbar Area -->
        
        <!-- Start Main Banner Area -->
        <div class="main-banner-section jarallax" data-jarallax='{"speed": 0.3}'>
            <div class="d-table">
                <div class="d-table-cell">
                    <div class="container">
                        <div class="row align-items-center">
                            <div class="col-lg-6 col-md-12">
                                <div class="banner-content">
                                    <h1>Grow your fund! </h1>
                                    <p>Get 20% interest in 6 months on investment.</p>
                                    
                                </div>
                            </div>

                            <div class="col-lg-6 col-md-12">
                                <div class="money-transfer-form">
                                    <form>
                                        <div class="form-group">
                                            <label>Investment Calculator</label>
                                            <div class="money-transfer-field">
                                                
                                            </div>
                                        </div>
                                        
                                        <div class="form-group">
                                            <label>Investment Amount</label>
                                            <div class="money-transfer-field">
                                                <input type="number" step="1000" min="1000" value="1000" name="loan_amount_needed" id="loan_amount_needed" class="form-control" autocomplete="off" onkeyup="sum();" oninput="sum()" onchange="sum()">

                                                <div class="amount-currency-select">
                                                    <select>
                                                        <option>&#x20a6;</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- <div class="currency-info">
                                            <div class="bar"></div>
                                            <span><strong>20%</strong> interest per month</span>
                                        </div> -->

                                        <div class="form-group">
                                            <label>Investment duration</label>
                                            <div class="money-transfer-field">
                                                <input type="text" name="duration" id="duration" readonly value="6 months" class="form-control" autocomplete="off" onkeyup="sum();" oninput="sum()" onchange="sum()">

                                                
                                            </div>
                                        </div>

                                        
                                        <div class="form-group">
                                            <label>Expected Returns</label>
                                            <div class="money-transfer-field">
                                                <input type="text" class="form-control" value="1200" name="tot_amount" id="tot_amount" autocomplete="off" readonly>

                                                <div class="amount-currency-select">
                                                    <select>
                                                        <option>&#x20a6;</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="money-transfer-info">
                                            <span></span>
                                        </div>

                                        <a href="dashboard/signup.php"><button type="button" class="btn btn-primary">Invest</button></a>

                                        <div class="terms-info">
                                            <p>By clicking Invest, I am agree with <a href="tandc.php">Terms &amp; Policy</a></p>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Main Banner Area -->

        <!-- Start Featured Boxes Area -->
        <section class="featured-boxes-area">
            <div class="container">
                <div class="featured-boxes-inner">
                    <div class="row m-0">
                        <div class="col-lg-3 col-sm-6 col-md-6 p-0">
                            <div class="single-featured-box">
                                <div class="icon color-fb7756">
                                    <i class="flaticon-piggy-bank"></i>
                                </div>

                                <h3>Transparent Pricing</h3>
                                
                                <a href="features-1.html" class="read-more-btn">Read More</a>
                            </div>
                        </div>

                        <div class="col-lg-3 col-sm-6 col-md-6 p-0">
                            <div class="single-featured-box">
                                <div class="icon color-facd60">
                                    <i class="flaticon-data-encryption"></i>
                                </div>

                                <h3>Fully Encrypted</h3>
                                
                                <a href="features-1.html" class="read-more-btn">Read More</a>
                            </div>
                        </div>

                        <div class="col-lg-3 col-sm-6 col-md-6 p-0">
                            <div class="single-featured-box">
                                <div class="icon color-1ac0c6">
                                    <i class="flaticon-wallet"></i>
                                </div>

                                <h3>Instant Cashout</h3>
                                
                                <a href="features-1.html" class="read-more-btn">Read More</a>
                            </div>
                        </div>

                        <div class="col-lg-3 col-sm-6 col-md-6 p-0">
                            <div class="single-featured-box">
                                <div class="icon">
                                    <i class="flaticon-shield"></i>
                                </div>

                                <h3>Safe and Secure</h3>
                                
                                <a href="features-1.html" class="read-more-btn">Read More</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Featured Boxes Area -->

        <!-- Start How It Works Area -->
        <section class="how-it-works-area ptb-70">
            <div class="container">
                <div class="section-title">
                    <h2>How atom invest works</h2>
                    <div class="bar"></div>
                    <p>Create a free account and invest with the few steps below.</p>
                </div>

                <div class="row">
                    <div class="col-lg-4 col-sm-6 col-md-6">
                        <div class="single-how-it-works">
                            <img src="assets/img/how-it-works-image/1.png" alt="image">

                            <h3>1. Register for free</h3>
                            <p>Click<a href="register.php" style="color:blue;"> here</a> to register for free. It takes less than 2 minutes to register. </p>
                        </div>
                    </div>

                    <div class="col-lg-4 col-sm-6 col-md-6">
                        <div class="single-how-it-works">
                            <img src="assets/img/how-it-works-image/5.png" alt="image">

                            <h3>2. Invest</h3>
                            <p>Invest and wait. ROI is 20% in 6 months.</p>
                        </div>
                    </div>

                    <div class="col-lg-4 col-sm-6 col-md-6">
                        <div class="single-how-it-works">
                            <img src="assets/img/how-it-works-image/3.png" alt="image">

                            <h3>3. Credited</h3>
                            <p>In 6 months you will be credited with your invested amount + 20% interest.</p>
                        </div>
                    </div>

                    
                </div>
            </div>
        </section>
        <!-- End How It Works Area -->
        

        <!-- Start Account Create Area -->
        <section class="account-create-area">
            <div class="container">
                <div class="account-create-content">
                    <h2>Create an account Now</h2>
                    <p>It takes less than 2 minutes to open an account</p>
                    <a href="dashboard/signup.php" class="btn btn-primary">Get Your atom Account</a>
                </div>
            </div>
        </section>
        <!-- End Account Create Area -->
        
        <!-- Start Footer Area -->
		<?php include_once 'footer.php'; ?>
        <!-- End Footer Area -->
        
        <div class="go-top"><i class="fas fa-arrow-up"></i></div>


        <script>
            
        function sum() {
              var txtFirstNumberValue = document.getElementById('loan_amount_needed').value;
              var txtSecondNumberValue = document.getElementById('duration').value;
              var firstCal = parseFloat(txtFirstNumberValue);
              //var secondCal = parseFloat(txtSecondNumberValue * 0.2);
              var interest = parseFloat(firstCal * 0.2);
              var total = parseFloat(firstCal + interest);
                  //(result1).toFixed(2);
              //var total = parseInt(txtFirstNumberValue) + interest;
              if (!isNaN(total)) {
                 document.getElementById('tot_amount').value = total;
              }
        }
           
           
        </script>

        <!-- Links of JS files -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/popper.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/jquery.meanmenu.js"></script>
        <script src="assets/js/jquery.nice-select.min.js"></script>
        <script src="assets/js/slick.min.js"></script>
        <script src="assets/js/jquery.magnific-popup.min.js"></script>
		<script src="assets/js/jquery.appear.min.js"></script>
        <script src="assets/js/odometer.min.js"></script>
        <script src="assets/js/owl.carousel.min.js"></script>
        <script src="assets/js/parallax.min.js"></script>
        <script src="assets/js/wow.min.js"></script>
        <script src="assets/js/form-validator.min.js"></script>
        <script src="assets/js/contact-form-script.js"></script>
        <script src="assets/js/main.js"></script>
    </body>

</html>