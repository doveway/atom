<div class="navbar-area">
            <div class="luvion-responsive-nav">
                <div class="container">
                    <div class="luvion-responsive-menu">
                        <div class="logo">
                            <a href="index-3.html">
                                <img src="assets/img/logo.png" alt="logo">
                                <img src="assets/img/black-logo.png" alt="logo">
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="luvion-nav">
                <div class="container">
                    <nav class="navbar navbar-expand-md navbar-light">
                        <a class="navbar-brand" href="index.php">
                            <img src="assets/img/logo.png" alt="logo">
                            <img src="assets/img/black-logo.png" alt="logo">
                        </a>

                        <div class="collapse navbar-collapse mean-menu" id="navbarSupportedContent">
                            <ul class="navbar-nav">
                                <li class="nav-item"><a href="index.php" class="nav-link">Home</a></li>
                                
                                <li class="nav-item"><a href="dashboard/login.php" class="nav-link">Get A Loan</a></li>
                                
                                <li class="nav-item"><a href="invest.php" class="nav-link">Invest</a></li>

                                
                                <li class="nav-item"><a href="agent.php" class="nav-link">Become An Agent</a></li>
                                
                                <li class="nav-item"><a href="faq.php" class="nav-link">FAQ</a></li>

                                <li class="nav-item"><a href="contact.php" class="nav-link">Contact</a></li>
                            </ul>

                            <div class="others-options">
                                <a href="dashboard/login.php" class="login-btn"><i class="flaticon-user"></i> Log In</a>
                            </div>
                        </div>
                    </nav>
                </div>
            </div>
        </div>