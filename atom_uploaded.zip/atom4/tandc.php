
<?php
include_once 'secure.php';
?>
<!doctype html>
<html lang="zxx">
<head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <!-- Links of CSS files -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/css/animate.min.css">
        <link rel="stylesheet" href="assets/css/fontawesome.min.css">
        <link rel="stylesheet" href="assets/css/flaticon.css">
        <link rel="stylesheet" href="assets/css/magnific-popup.min.css">
        <link rel="stylesheet" href="assets/css/nice-select.css">
        <link rel="stylesheet" href="assets/css/slick.min.css">
        <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
        <link rel="stylesheet" href="assets/css/meanmenu.css">
		<link rel="stylesheet" href="assets/css/odometer.min.css">
        <link rel="stylesheet" href="assets/css/style.css">
        <link rel="stylesheet" href="assets/css/responsive.css">

        <title>ATOM LOANS::Terms &amp; Conditions</title>

        <link rel="icon" type="image/png" href="assets/img/favicon.png">
    </head>

        <!-- Preloader -->
        <div class="preloader">
            <div class="loader">
                <div class="shadow"></div>
                <div class="box"></div>
            </div>
        </div>
        <!-- End Preloader -->

        <!-- Start Navbar Area -->
        <?php include_once 'navbar.php'; ?>
        <!-- End Navbar Area -->
        
        <!-- Start Page Title Area -->
        <div class="page-title-area item-bg1 jarallax" data-jarallax='{"speed": 0.3}'>
            <div class="container">
                <div class="page-title-content">
                    <h2>T &amp; C</h2>
                    <p>Terms &amp; Conditions</p>
                </div>
            </div>
        </div>
        <!-- End Page Title Area -->

        <!-- Start FAQ Area -->
        <section class="faq-area ptb-70">
            <div class="container">
                
                <div class="faq-contact">
                    <div>
                        <h2></h2>
                        <div class="bar"></div>
                        <p>Atom loans retains every right on this website to provide you with information about products and services provided by or through us, and information about Atom loans. Please read these Terms and Conditions carefully before accessing or using this Website.</p>

<p>By accessing or using the Website, you agree to these Terms and Conditions. Atom loans reserves the right to make alterations at any time to any portion of the terms. Please ensure to frequently look up these terms for cases of modification or reform.</p>

<p>Accessing this website means you agree to these terms,if not do not continue. If you have any questions about this Agreement, please contact us via our email as displayed on the website.</p>

<h4>NO WARRANTY</h4>
<p>We created this Website for the convenience of our Internet visitors. The information (including text, graphics and functionality) is presented “as is” and “as available” without express or implied warranties including, but not limited to, implied warranties of non-infringement, merchantability and fitness for a particular purpose. We expressly disclaim any liability for errors and omissions regarding the information and materials contained in the Website. Due to the nature of the Internet, we cannot guarantee the accuracy or completeness of the information contained in this Website or its suitability for any purpose.</p>

<h4>VIRUSES</h4>
<p>Due to the marked increase in the fabrication and proliferation of computer viruses affecting the Internet, we want to warn you about infections or viral contamination on your system. It is your responsibility to scan any and all downloaded materials received from the Internet. We are not responsible or liable for any damage caused by such hazards.</p>

                        <h4>LIMITATION OF LIABILITY</h4>
<p>Your use of the Website is at your own risk. To the maximum extent permitted by law, neither Atom loans nor any other party involved in creating, producing or delivering the Website, will be liable for any direct, indirect, incidental, consequential or punitive damages (including, without limitation, loss of profits, cost of substitute service or lost opportunity), howsoever caused, arising out of your access to, use of, or reliance on the Website, even if Atom loans has been advised of the possibility of such damages. Without limiting the foregoing, Atom loans assumes no responsibility for, and will not be liable for any damages relating to or caused by any viruses which may affect your computer equipment or other property on account of your access to, use of, or downloading from, the Website. Atom loans cannot and does not guarantee continuous, uninterrupted or secure access to the Website. You specifically acknowledge and agree that Atom loans is not liable for any defamatory, offensive, fraudulent, or otherwise illegal conduct of any user.</p>

                        <h4>INDEMNITY</h4>
<p>You agree to indemnify and hold Atom loans, its subsidiaries or affiliates, and their respective directors, officers, employees, and agents, harmless against any and all liabilities, claims and expenses, including reasonable attorneys’ fees, arising from breach of these Terms and Conditions, any other related policy, your use or access of the Website or any Internet site linked to or from the Website, or in connection with the transmission of any content on the Website.</p>

                        <h4>AUTHORISED USE</h4>
<p>The information provided on this Website is solely for the personal use of Website users. You are authorised to view and copy the information available on this Website for personal purposes only, provided that any copies include any trade mark notices as they may appear on those pages copied. Except for the personal use of Website users, you may not copy, reproduce, modify, display, distribute, perform, disseminate, transmit, transfer, sell, license, publish, use to create a derivative work, or use for any public or commercial purposes any of the contents of this Website without the express prior written consent of Atom loans. You agree to access and use the Website only for lawful purposes.</p>

                        <h4>LINKS TO THIS WEBSITE</h4>
<p>Atom loans has not reviewed all of the sites which are linked to the Website, and the fact of such links does not indicate any endorsement, authorisation, sponsorship or affiliation with respect to the material contained on any linked site. Atom loans is not responsible for the contents of any site linked to the Website. Your connection to and use of any such linked site is at your own risk.</p>

                        <h4>COPYRIGHTS AND TRADE MARKS</h4>
<p>Copyrights of the pages and the screens displaying the pages, and the information and material therein, is owned by Atom loans unless otherwise indicated and may not be distributed, modified, reproduced in whole or in part without the prior written permission of Atom loans. The display of trade marks herein does not imply that a license of any kind has been granted. Any downloading, re-transmission, or other copying or modification of the trademarks and/or the contents herein may be a violation of applicable laws and regulations and could subject the copier to legal action. The trademarks and logos (collectively the “Trade Marks”) displayed on this site, unless otherwise indicated, are registered and unregistered trademarks of Atom loans and its subsidiaries and affiliates. Atom loans and its trademarks may only be used publicly with the permission of Atom loans and with proper acknowledgement. Use of any Atom loans trademarks without the prior written consent of Atom loans may constitute copyright infringement or passing off in violation of applicable laws.</p>

                        <h4>SECURITY</h4>
<p>We welcome your email correspondence. But Internet and email communications are not confidential. It is possible that information transmitted to us may be read or obtained by other parties. In an attempt to protect your privacy, our email responses do not include personal account information such as your BVN or bank account numbers. Email is an important communication channel for our Website’s visitors. We will use your email address and the content of any email for correspondence purposes and to meet our legal and regulatory requirements regarding customer communications. On occasion, we may use your email address to send you communications with information about service and product information that we believe may be of interest to you. If you do not want to receive such unsolicited communications from us, please send us a message to this effect.</p>

                        <h4>GOVERNING LAW</h4>
<p>You agree that the use of this site shall be governed by and construed in accordance with the laws of the Federal Republic of Nigeria.</p>

                        <h4>LOAN RECOVERY</h4>
<p>Collaterals will be sold to recover defaulting loans. </p>
                    </div>

                    
                </div>
            </div>
        </section>
        <!-- End FAQ Area -->

        <!-- Start Account Create Area -->

        <!-- End Account Create Area -->
        
        <!-- Start Footer Area -->
		<?php include_once 'footer.php'; ?>
        <!-- End Footer Area -->
        
        <div class="go-top"><i class="fas fa-arrow-up"></i></div>

        <!-- Links of JS files -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/popper.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/jquery.meanmenu.js"></script>
        <script src="assets/js/jquery.nice-select.min.js"></script>
        <script src="assets/js/slick.min.js"></script>
        <script src="assets/js/jquery.magnific-popup.min.js"></script>
		<script src="assets/js/jquery.appear.min.js"></script>
        <script src="assets/js/odometer.min.js"></script>
        <script src="assets/js/owl.carousel.min.js"></script>
        <script src="assets/js/parallax.min.js"></script>
        <script src="assets/js/wow.min.js"></script>
        <script src="assets/js/form-validator.min.js"></script>
        <script src="assets/js/contact-form-script.js"></script>
        <script src="assets/js/main.js"></script>
    </body>

<!-- Mirrored from templates.envytheme.com/luvion/default/faq.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 03 Aug 2020 23:33:02 GMT -->
</html>